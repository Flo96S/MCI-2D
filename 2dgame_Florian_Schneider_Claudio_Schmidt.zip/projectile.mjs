import * as cl from "./canvas_lib.mjs";

export function Projectile(ctx, x, y, rotX, rotY) {
   let speed = 20;
   let posX = x, posY = y;
   let size = 5;
   let _rotX = rotX, _rotY = rotY;

   function draw() {
      ctx.resetTransform();
      //ctx.translate(x, y);
      //ctx.rotate(rotation);
      cl.circle(ctx, posX, posY, size, '#FFF', '#FF0', 2);
      ctx.resetTransform();
      posX += speed * _rotX;
      posY += speed * _rotY;
   }

   function isInside(mouseX, mouseY) {
      //inside = cl.distance(x, y, mouseX, mouseY) > radius;
      return false;
   }

   function move() {
      if (posX > 2000) return;
      posX += speed * _rotX;
      posY += 0 * _rotY;
   }

   function reset() {

   }

   return { draw, isInside, move, reset }
}